# Getting Started with CenterPoint

## nuScenes
Please refer to [nuScenes](NUSC.md) for details.

## Waymo
Please refer to [WAYMO](WAYMO.md) for details. 